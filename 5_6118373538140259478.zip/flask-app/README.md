# Flask_Registration_MongoDB
Simple Flask registration, login, logout system using NoSQL(MongoDB) 

# Requirements 
Mongodb on user system 

https://docs.mongodb.com/manual/installation/

Installed packages on python interpreter
 `Flask, render_template, request, url_for, redirect, session, pymongo, bcrypt`
 
In a more detailed aprroach see my blog:

https://richard-taujenis.medium.com/simple-registration-login-system-with-flask-mongodb-and-bootstrap-8872b16ef915?postPublishedType=initial
